<footer class="main-footer">
    <div class="footer-left">
        <a href="{{ route('home') }}">Dream Chalets Engineering</a></a>
    </div>
    <div class="footer-right">
    </div>
</footer>