<?php if($message = Session::get('success')): ?>
<script>
  iziToast.success({
    title: 'Congratulations!',
    message: '<?php echo e($message); ?>',
    position: 'topRight'
  });
</script>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<script>
   iziToast.error({
    title: 'Ooops!',
    message: '<?php echo e($message); ?>',
    position: 'topRight'
  });
</script>
<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
<script>
  iziToast.warning({
    title: 'Oops!',
    message: '<?php echo e($message); ?>',
    position: 'topRight'
  });
</script>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
<script>
  iziToast.info({
    title: 'Message!',
    message: '<?php echo e($message); ?>',
    position: 'topRight'
  });
</script>
<?php endif; ?>

<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script>
  iziToast.error({
    title: 'Oops!',
    message: '<?php echo e($error); ?>',
    position: 'topRight'
  });
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/partials/flash-message.blade.php ENDPATH**/ ?>