<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <?php if($title): ?>
    <title><?php echo e($title); ?> - DCE</title>
    <?php else: ?>
    <title>DCE Portal</title>
    <?php endif; ?>

    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/feather.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>
    <div class="main-wrapper login-body">
        <div class="container">

            <header class="log-header">
                <a href="<?php echo e(route('home')); ?>"><img class="img-fluid logo-dark" src="<?php echo e(asset('assets/img/dce_logo_2.png')); ?>" width="150" height="100" alt="Logo"></a>
            </header>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>


    <script src="<?php echo e(asset('assets/js/jquery-3.6.4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/layouts/blank.blade.php ENDPATH**/ ?>