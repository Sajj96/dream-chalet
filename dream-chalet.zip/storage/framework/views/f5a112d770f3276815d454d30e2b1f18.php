<?php use App\Models\HouseType;
    $house_types = HouseType::get();
?>
<header class="header header-fix">
    <div class="header-top">
        <div class="template-ad">
            <img src="<?php echo e(asset('assets/img/icons/badge-icon.svg')); ?>" alt="icon">
            <h5>No 1, Realestate Website to Buy / Sell Your Place <span>First Listing Free!!!</span></h5>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg header-nav">
        <div class="navbar-header">
            <a id="mobile_btn" href="javascript:void(0);">
                <span class="bar-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            </a>
            <a href="<?php echo e(route('home')); ?>" class="navbar-brand logo">
                <img src="<?php echo e(asset('assets/img/dce_logo.png')); ?>" class="img-fluid" alt="Logo">
            </a>
        </div>
        <div class="main-menu-wrapper">
            <div class="menu-header">
                <a href="<?php echo e(route('home')); ?>" class="menu-logo">
                    <img src="<?php echo e(asset('assets/img/dce_logo.png')); ?>" class="img-fluid" alt="Logo">
                </a>
                <a id="menu_close" class="menu-close" href="javascript:void(0);">
                    <i class="fas fa-times"></i>
                </a>
            </div>
            <ul class="main-nav">
                <li class="active">
                    <a href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li class="has-submenu">
                    <a href="javascript:void(0);">House Plans <i class="fas fa-chevron-down"></i></a>
                    <ul class="submenu">
                        <li class="has-submenu">
                            <a href="javascript:void(0);">House Sizes</a>
                            <ul class="submenu">
                                <li><a href="<?php echo e(route('property', 'bedroom=1')); ?>">1 Bedroom</a></li>
                                <li><a href="<?php echo e(route('property', 'bedroom=2')); ?>">2 Bedrooms</a></li>
                                <li><a href="<?php echo e(route('property', 'bedroom=3')); ?>">3 Bedrooms</a></li>
                                <li><a href="<?php echo e(route('property', 'bedroom=4')); ?>">4 Bedrooms</a></li>
                                <li><a href="<?php echo e(route('property', 'bedroom=5')); ?>">5+ Bedrooms</a></li>
                            </ul>
                        </li>
                        <li class="has-submenu">
                            <a href="javascript:void(0);">House Types</a>
                            <ul class="submenu">
                                <?php $__currentLoopData = $house_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('property', $type->name.'='.$type->id)); ?>"><?php echo e($type->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                <li><a href="contact-us.html">Blog</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                <li class="searchbar">
                    <a href="javascript:void(0);">
                        <img src="<?php echo e(asset('assets/img/icons/search-icon.svg')); ?>" alt="img">
                    </a>
                </li>
                <?php if(auth()->check()): ?>
                <li class="login-link"><a href="#">My Profile</a></li>
                <li class="login-link">
                    <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form-one').submit();">Logout</a>
                    <form id="logout-form-one" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
                <?php else: ?>
                <li class="login-link"><a href="<?php echo e(route('login')); ?>">Sign Up</a></li>
                <li class="login-link"><a href="<?php echo e(route('register')); ?>">Sign In</a></li>
                <?php endif; ?>
            </ul>
        </div>
        <ul class="nav header-navbar-rht">
            <?php if(auth()->check()): ?>
            <li class="new-property-btn dropstart">
                <a href="javascript:void(0);" class="active dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="bx bxs-user-circle bx-md"></i> <?php echo e(auth()->user()->name); ?></a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">My Profile</a></li>
                    <li>
                        <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </li>
            <?php else: ?>
            <li>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary"><i class="feather-user-plus"></i>Sign Up</a>
            </li>
            <li>
                <a href="<?php echo e(route('login')); ?>" class="btn sign-btn"><i class="feather-unlock"></i>Sign In</a>
            </li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
<?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/partials/navigation.blade.php ENDPATH**/ ?>