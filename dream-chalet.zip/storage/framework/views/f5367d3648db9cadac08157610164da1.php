<?php $__env->startSection('content'); ?>
<div class="login-wrapper">
    <div class="loginbox">
        <div class="login-auth">
            <div class="login-auth-wrap">
                <h1><?php echo e(__('Hey There!!! Welcome Back.')); ?></h1>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-label"><?php echo e(__('Email Address')); ?> <span>*</span></label>
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="login" value="<?php echo e(old('login')); ?>" placeholder="Enter Email" required autofocus>
                        <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label"><?php echo e(__('Password')); ?> <span>*</span></label>
                        <div class="pass-group">
                            <input id="password" type="password" class="form-control pass-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Enter Password">
                            <span class="fas fa-eye toggle-password"></span>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <?php if(Route::has('password.request')): ?>
                    <div class="form-group mb-5">
                        <a class="forgot-link" href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Password ?')); ?></a>
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label class="custom_check mt-0 mb-0"><span><?php echo e(__('Remember me')); ?></span>
                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <span class="checkmark"></span>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-outline-light w-100 btn-size"><?php echo e(__('Sign In')); ?></button>

                    <div class="text-center dont-have"><?php echo e(__('Don\'t have an account ?')); ?> <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Sign Up')); ?></a></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blank', ['title' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/auth/login.blade.php ENDPATH**/ ?>