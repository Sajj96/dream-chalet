<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/bundles/datatables/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e(__('House Types')); ?></h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(url('dashboard/house-types/add')); ?>" class="btn btn-primary p-2"><i data-feather="plus-circle"></i> Add House Type</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="table-1">
                                <thead>
                                    <tr>
                                        <th class="text-center">
                                            #
                                        </th>
                                        <th><?php echo e(__('Name')); ?></th>
                                        <th><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $house_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($type->name); ?></td>
                                        <td>
                                        <a href="#" class="btn btn-outline-danger" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($type->id); ?>').submit();">Delete</a>
                                        <form id="delete-form-<?php echo e($type->id); ?>" action="<?php echo e(url('/dashboard/house-types/delete')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="type_id" value="<?php echo e($type->id); ?>">
                                        </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/dashboard/bundles/datatables/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $("#table-1").dataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/pages/dashboard/house_types/index.blade.php ENDPATH**/ ?>