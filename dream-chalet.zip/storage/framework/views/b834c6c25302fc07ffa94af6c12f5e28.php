<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Add Amenities</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('dashboard.stage.add')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="group">
                                <div class="form-group row clone mb-4">
                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Stage</label>
                                    <div class="col-sm-12 col-md-7">
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" name="stage[]" placeholder="" aria-label="">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" id="add-btn" type="button">Add Another</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row mb-4">
                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                <div class="col-sm-12 col-md-7">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).on('click', '#add-btn', function() {

        var html = `
            <div class="form-group row clone mb-4">
                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Stage</label>
                <div class="col-sm-12 col-md-7">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="stage[]" placeholder="" aria-label="">
                        <div class="input-group-append">
                            <button class="btn btn-danger remove" type="button">Remove</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $(".group").append(html);

    });

    $("body").on("click", ".remove", function() {
        $(this).parents(".clone").remove();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/pages/dashboard/house_stages/add.blade.php ENDPATH**/ ?>