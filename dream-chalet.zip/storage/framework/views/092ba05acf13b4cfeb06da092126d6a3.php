<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="https://www.nougattechnologies.co.tz/" />
    <meta name="keywords" content="Dream Chalets Engineering,Real estate,Dalali wa viwanja,Natafuta nyumba,Natafuta nyumba ya kupanga,Real estate companies in tanzania,Real estate agents in tanzania,Natafuta kiwanja,Property listing website,Property listing agencies">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="robots" content="follow, index, max-snippet:-1, max-video-preview:-1, max-image-preview:large">

    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>" />
    <meta property="og:title" content="Dream Chalets Engineering" />
    <meta property="og:description" content="Dream Chalets Engineering" />
    <meta property="og:site_name" content="Dream Chalets Engineering" />
    <meta property="og:image" content="<?php echo e(asset('assets/img/dce_logo.png')); ?>" />
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:site" content="<?php echo e(env('APP_URL')); ?>" />
    <meta property="twitter:title" content="Dream Chalets Engineering" />
    <meta property="twitter:description" content="Dream Chalets Engineering" />
    <meta property="twitter:image" content="<?php echo e(asset('assets/img/dce_logo.png')); ?>" />
    <meta property="twitter:image:alt" content="Company logo" />
    <link rel="canonical" href="<?php echo e(url()->current()); ?>" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php if($title): ?>
    <title><?php echo e($title); ?> - DCE</title>
    <?php else: ?>
    <title>DCE Portal</title>
    <?php endif; ?>

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/img/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/img/site.webmanifest')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('assets/img/safari-pinned-tab.svg')); ?>" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <!-- Styles -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>" type="image/x-icon">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/feather.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/boxicons/css/boxicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/aos/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/swiper/swiper.min.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <style>
        @media print {

            html,
            body {
                display: none;
                /* hide whole page */
            }
        }
    </style>

</head>

<body>
    <div class="main-wrapper">
        <?php echo $__env->make('partials.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.search_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="progress-wrap active-progress">
        <svg class="progress-circle svg-content" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"></path>
        </svg>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/slick/slick.js ')); ?>  "></script>

    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/aos/aos.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/swiper/swiper.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/waypoints.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.counterup.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <script>
        window.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        }, false);
    </script>
</body>

</html><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/layouts/app.blade.php ENDPATH**/ ?>