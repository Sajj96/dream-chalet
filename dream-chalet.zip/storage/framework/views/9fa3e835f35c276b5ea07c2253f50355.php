

<?php $__env->startSection('content'); ?>
<div class="error-page">
    <div class="error-box">
        <img src="<?php echo e(asset('assets/img/404.png')); ?>" width="200" class="img-fluid" alt="Page not found">
        <h1>Oops! Page Not Found!</h1>
        <p>The page you requested was not found.</p>
        <div class="back-button">
            <a href="<?php echo e(route('home')); ?>" class="btn">Back to Home</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blank', ['title' => 'Not Found Resource'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/errors/404.blade.php ENDPATH**/ ?>