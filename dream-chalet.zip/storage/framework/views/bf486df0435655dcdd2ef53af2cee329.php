<footer class="main-footer">
    <div class="footer-left">
        <a href="<?php echo e(route('home')); ?>">Dream Chalets Engineering</a></a>
    </div>
    <div class="footer-right">
    </div>
</footer><?php /**PATH C:\Users\Developer-3\Downloads\Code\dream-chalet\resources\views/partials/dashboard/footer.blade.php ENDPATH**/ ?>